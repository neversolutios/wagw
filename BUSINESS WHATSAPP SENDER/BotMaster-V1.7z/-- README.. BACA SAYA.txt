if application Error.. "corewebview2 is uninitialized and unable to complete..."
Please Install MicrosoftEdgeWebview2Setup.exe in this folder

if still error, please install Visual C++ Redistributable
download  here : https://drive.google.com/drive/folders/1FBe1zy3PRt0NGP4pJN2neFkoXMFW8SIm?usp=sharing

By purchasing this Botmaster app
You GET FREE APPLICATION !!
- WG LITE  https://lite.wa-gw.com
- WG JS    https://js.wa-gw.com

Please download as an alternative if there are problems with Botmaster

-----------------------------------------------------------------------------------
Jika aplikasi Error .. "corewebview2 is uninitialized and unable to complete..."
Silakan Instal MicrosoftEdgeWebview2Setup.exe di folder ini

jika masih error, silahkan install Visual C++ Redistributable
unduh di sini: https://drive.google.com/drive/folders/1FBe1zy3PRt0NGP4pJN2neFkoXMFW8SIm?usp=sharing

Dengan membeli aplikasi Botmaster ini
Anda MENDAPATKAN APLIKASI GRATIS!!
- WG LITE https://lite.wa-gw.com
- WG JS https://js.wa-gw.com

Silakan unduh sebagai alternatif jika ada masalah dengan Botmaster